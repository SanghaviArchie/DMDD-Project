# Requirements
python 3.8.9
pip 20.2.3

# Packages
unixodbc(install by apt or brew depending on OS)
pandas
streamlit

# Running the APP
Run the following command to up the application
streamlit run "Absolute Path to main file"

# Configuring Database
Update the following values to connect to the Database in DatabaseConn.py   
SERVER , DATABASE , USERNAME ,PASSWORD 