import io

import pyodbc
import streamlit as st
from PIL import Image
import pandas as pd
from DatabaseConn import DBConn


def app():
    st.write("Welcome to the Vendor Page")
    st.subheader("Image")
    image_file = st.file_uploader("Upload Images", type=["png", "jpg", "jpeg"])
    con = DBConn().conn_to_db()
    cur = con.cursor()
    if st.button("Upload"):
        img = load_image(image_file)
        sql = "INSERT INTO imgtest (myimage) VALUES (?)"
        cur.execute(sql, (pyodbc.Binary(img),))
        con.commit()
    if st.button("View"):
        res = pd.read_sql('SELECT myimage FROM imgtest WHERE id = 11', con)
        image = list(res['myimage'])[0]
        st.image(image, caption='Sunrise by the mountains')
    if st.button("Slider"):
        age = st.slider('How old are you?', "cart", "paid", "delivered")
        st.write("I'm ", age, 'years old')


def load_image(image_file):
    img = Image.open(image_file)
    im_resize = img.resize((500, 500))
    rgb_im = im_resize.convert('RGB')
    b = io.BytesIO()
    rgb_im.save(b, format='JPEG')
    im_bytes = b.getvalue()
    return im_bytes