import streamlit as st


def app():
    
    st.title("Welcome to the Admin Page")
