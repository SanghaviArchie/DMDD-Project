import io

import pyodbc
import streamlit as st
from PIL import Image
from DatabaseConn import DBConn
import pandas as pd

Producttable = "Product"


def app():
    st.header("Welcome to the Product Page")
    st.subheader("Create Product")
    product_name = st.text_input("Product Name", None)
    price = st.text_input("Price", None)
    quantity = st.text_input("Quantity", None)
    category = st.text_input("Category", "")
    dimensions = st.text_input("Dimenisons", "")
    brand = st.text_input("Brand", "")
    color = st.text_input("Color", "")
    size = st.text_input("Size", "")
    # check for vendor id to select created by
    connection = DBConn().conn_to_db()
    if st.button("Create"):
        # insert into DB
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO[dbo].[PRODUCT] ([ProductName], [Price], [Quantity], [Category], [Dimensions], [Brand], "
            "[Color], [Size]) "
            "VALUES('{0}', {1}, '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')".format(product_name, price,
                                                                                           quantity,
                                                                                           category, dimensions,
                                                                                           brand, color, size))
        connection.commit()
    st.subheader("Image")
    image_file = st.file_uploader("Upload Images", type=["png", "jpg", "jpeg"])
    if st.button("Upload"):
        img = load_image(image_file)
        sql = "UPDATE Product SET ProductImage = (?) WHERE ProductName = '{0}'".format(product_name)
        connection.cursor().execute(sql, (pyodbc.Binary(img),))
        connection.commit()
    if st.button("View"):
        res = pd.read_sql("SELECT ProductImage FROM Product WHERE ProductName = '{0}'".format(product_name), connection)
        image = list(res['ProductImage'])[0]
        st.image(image, caption='Product Info')

    # Update the product details
    st.subheader("Update Product info")
    u_product_name = st.text_input(" u Product Name", "")
    u_price = st.text_input("u Price", "")
    u_category = st.text_input("u Category", "")
    data = pd.read_sql("Select * from {0} ".format("Product"), connection)
    selected_upid = st.selectbox('Please Select the Product to update',
                                 data['ProductID'])
    if st.button("Update"):
        update(selected_upid, u_product_name, u_price, u_category, connection)
        st.write("Product Updated Succesfully")

    # Delete Product
    st.subheader("Delete Product info")
    selected_dpid = st.selectbox('Please Select the Product to delete',
                                 data['ProductID'])
    if st.button("Delete"):
        delete(selected_dpid, connection)
        st.write("Product Deleted Successfully")
    # view the product details
    st.subheader("Product Details")
    data = pd.read_sql("Select * from {0} ORDER BY ProductName ".format("Product"), connection)
    st.dataframe(data)


def update(pid, pname, pprice, pcat, connection):
    cursor = connection.cursor()
    if pname:
        cursor.execute("UPDATE {0} SET ProductName = '{1}'  WHERE ProductID = '{2}'".format(Producttable, pname, pid))
    if pprice:
        cursor.execute("UPDATE {0} SET Price = '{1}'  WHERE ProductID = '{2}'".format(Producttable, pprice, pid))
    if pcat:
        cursor.execute("UPDATE {0} SET Category = '{1}'  WHERE ProductID = '{2}'".format(Producttable, pcat, pid))
    connection.commit()


def delete(pid, connection):
    cursor = connection.cursor()
    cursor.execute("Delete From {0}  WHERE ProductID = '{1}'".format(Producttable, pid))
    connection.commit()


def load_image(image_file):
    img = Image.open(image_file)
    im_resize = img.resize((500, 500))
    rgb_im = im_resize.convert('RGB')
    b = io.BytesIO()
    rgb_im.save(b, format='JPEG')
    im_bytes = b.getvalue()
    return im_bytes
