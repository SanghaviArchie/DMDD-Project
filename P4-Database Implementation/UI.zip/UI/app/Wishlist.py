import streamlit as st
from DatabaseConn import DBConn
import pandas as pd

Ordertable = "Order"


def app():
    st.write("Welcome to the WishList Page")
    st.subheader("Fetch WishList")
    connection = DBConn().conn_to_db()
    cursor = connection.cursor()
    data_c = pd.read_sql("Select * from {0} ".format("Customer"), connection)
    selected_cna = st.selectbox('Please Select the Customer to update',
                                data_c['FirstName'])
    selectcidw = list(data_c.loc[(data_c["FirstName"] == selected_cna)]["CustomerID"])[0]
    data_wi = pd.read_sql("Select * from {0} ".format("Wishlist"), connection)
    if st.button("Fetch"):
        selected_cwish = data_wi.loc[(data_wi["CustomerID"] == selectcidw)]
        st.dataframe(selected_cwish)
    st.subheader("Add to Wishlist")
    data_pw = pd.read_sql("Select * from {0} ".format("Product"), connection)
    selected_cna = st.selectbox('Please Select the Customer to update',
                                data_pw['ProductName'])
    if st.button("Add to Wishlist"):

        selected_cwishpd = list(data_pw.loc[(data_pw["ProductName"] == selected_cna)]['ProductID'])[0]
        print(selected_cwishpd, selectcidw)
        cursor.execute(
            "INSERT INTO[dbo].[WISHLIST] ([ProductID], [CustomerID])"
            "VALUES('{0}', '{1}')".format(selected_cwishpd, selectcidw))
        cursor.commit()
        st.write("Updated Successfully")
