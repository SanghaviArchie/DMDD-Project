import streamlit as st
from DatabaseConn import DBConn
import pandas as pd

Customertable = "Customer"


def app():
    st.write("Welcome to the Order Details Page")
    st.subheader("Add Product to Order")
    cf_name = st.text_input("First Name", "")
    cl_name = st.text_input("Last name", "")
    address = st.text_input("Address", "")
    postalcode = st.text_input("Postal Code", "")
    email = st.text_input("Email", "")
    phone = st.text_input("Phone", "")
    city = st.text_input("City", "")
    # check for vendor id to select created by
    connection = DBConn().conn_to_db()

    if st.button("Create"):
        # insert into DB
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO[dbo].[Customer] ([FirstName], [LastName], [Address], [PostalCode], [Email], [PhoneNo], "
            "[City]) "
            "VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')".format(cf_name, cl_name, address, postalcode,
                                                                             email, phone, city))
        connection.commit()
    # Update the product details
    st.subheader("Update Customer info")
    u_first_name = st.text_input(" u Customer First Name", "")
    u_last_name = st.text_input("u Last Name", "")
    u_city = st.text_input("u City ", "")
    data = pd.read_sql("Select * from {0} ".format("Customer"), connection)
    selected_ucid = st.selectbox('Please Select the Customer to update',
                                 data['CustomerID'])
    if st.button("Update"):
        update(selected_ucid, u_first_name, u_last_name, u_city, connection)
        st.write("Customer Updated Succesfully")

    # Delete Product
    st.subheader("Delete Customer")
    selected_dcid = st.selectbox('Please Select the Product to delete',
                                 data['CustomerID'])
    if st.button("Delete"):
        delete(selected_dcid, connection)
        st.write("Customer Deleted Successfully")
    # view the product details\
    st.subheader("Customer Details")
    data = pd.read_sql("Select * from {0} ".format("Customer"), connection)
    st.dataframe(data)


def update(pid, cfirstname, clname, ccity, connection):
    cursor = connection.cursor()
    if cfirstname:
        cursor.execute("UPDATE {0} SET FirstName = '{1}'  WHERE CustomerID = '{2}'".format(Customertable, cfirstname, pid))
    if clname:
        cursor.execute("UPDATE {0} SET LastName = '{1}'  WHERE CustomerID = '{2}'".format(Customertable, clname, pid))
    if ccity:
        cursor.execute("UPDATE {0} SET City = '{1}'  WHERE CustomerID = '{2}'".format(Customertable, ccity, pid))
    connection.commit()


def delete(pid, connection):
    cursor = connection.cursor()
    cursor.execute("Delete From {0}  WHERE ProductID = '{1}'".format(Customertable, pid))
    connection.commit()
