import streamlit as st
from DatabaseConn import DBConn
import pandas as pd

Ordertable = "Order"


def app():
    st.write("Welcome to the Order Page")
    st.subheader("Track Order")
    connection = DBConn().conn_to_db()
    data_o = pd.read_sql("Select * from {0} ".format("Orders"), connection)
    data_p = pd.read_sql("Select * from {0} ".format("Product"), connection)
    selected_oid = st.selectbox('Please Select the Customer to update',
                                data_o['OrderID'])
    if st.button("Track"):
        selected_od = pd.read_sql("Select * from {0} Where OrderID='{1}'".format("Orders", selected_oid), connection)
        value = 0
        if list(selected_od['OrderStatus'])[0] == "delivered":
            value = 100
        elif list(selected_od['OrderStatus'])[0] == "shipped":
            value = 50
        st.progress(value)

    st.subheader("Add Products to Order")
    selected_oid_n = st.selectbox('Please Select the Order to update', data_o['OrderID'])
    selected_prd = st.selectbox('Please Select the Product to Add', data_p['ProductName'])
    selected_spr_quant = 1
    spr_pod_details = data_p.loc[(data_p["ProductName"] == selected_prd)]
    print(selected_prd)
    if selected_prd:
        slider_ph = st.empty()
        spr_quant = list(spr_pod_details['Quantity'])[0]
        selected_spr_quant = slider_ph.slider("Select Quantity", min_value=0, max_value=spr_quant)

    if st.button("Add to Cart"):
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO[dbo].[OrderDetails] ([OrderID], [ProductID], [ProductQuantity])"
            " VALUES('{0}', '{1}', '{2}')".format(selected_oid_n, list(spr_pod_details["ProductID"])[0],
                                                  selected_spr_quant))
        connection.commit()

    st.subheader("View Cart")
    if st.button("View Cart"):
        data_view_odid = pd.read_sql("Select * from OrderDetails Where OrderID='{0}'".format(selected_oid_n),
                                     connection)
        st.dataframe(data_view_odid)
    st.subheader("View Orders")
    data_view_oid = pd.read_sql("Select * from Orders ".format(selected_oid), connection)
    st.dataframe(data_view_oid)
