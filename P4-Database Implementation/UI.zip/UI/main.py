import streamlit as st
# import streamlit_authenticator as stauth
# import pandas as pd
from multipage import MultiPage
from app import  Customer, Wishlist, Product, Order

app = MultiPage()

st.write("""
# DMDD Final Project
 This is a demo *application!*
 """)
app.add_page("Customer", Customer.app)
app.add_page("Product", Product.app)
app.add_page("Order", Order.app)
app.add_page("WishList", Wishlist.app)

app.run()
