import pyodbc


class DBConn:
    db_conn = None

    def __init__(self):
        self.a = 1

    def conn_to_db(self):
        if not self.db_conn:
            server = '127.0.0.1'
            database = 'PROJECT'
            username = 'sa'
            password = 'reallyStrongPwd123'
            cnxn = pyodbc.connect(
                'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username +
                ';PWD=' + password)
            self.db_conn = cnxn
        return self.db_conn
